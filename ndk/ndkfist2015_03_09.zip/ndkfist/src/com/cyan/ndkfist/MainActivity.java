package com.cyan.ndkfist;

import com.cyan.ndkfist.natives.Arrays;
import com.cyan.ndkfist.natives.Functions;
import com.cyan.ndkfist.natives.SomeMathFunctions;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends Activity {
	static {
		System.loadLibrary("com_cyan_ndkfist_natives_Functions");
		System.loadLibrary("com_cyan_ndkfist_natives_SomeMathFunctions");
		System.loadLibrary("com_cyan_ndkfist_natives_Arrays");
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	protected void onResume() {
		super.onResume();
		String s = Functions.sayHello();
		int n1 = SomeMathFunctions.add(10, 2);// 12
		int n2 = SomeMathFunctions.subtract(10, 2);// 8
		int n3 = SomeMathFunctions.multiply(10, 2);// 20
		int n4 = SomeMathFunctions.divide(10, 2);// 5
		Toast.makeText(this, s + " " + n1 + " " + n2 + " " + n3 + " " + n4,
				Toast.LENGTH_LONG).show();

		int[] ints = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };// 55
		Log.d("Arrays.sumFromIntArray",
				"------------------sum=" + Arrays.sumFromIntArray(0, ints.length, ints));
		
		String [] strings={"now",",here"," i","s a"," ang","el","!!"};
		Log.d("Arrays.sumFromIntArray",
				"------------------after append:" + Arrays.appendString(0, strings.length, strings));
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
