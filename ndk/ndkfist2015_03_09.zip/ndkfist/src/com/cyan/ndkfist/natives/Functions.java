package com.cyan.ndkfist.natives;

public class Functions {
	public static native String sayHello();
}
