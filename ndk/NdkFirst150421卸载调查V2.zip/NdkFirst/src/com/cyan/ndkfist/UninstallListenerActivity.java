package com.cyan.ndkfist;

import com.cyan.ndkfirst.R;
import com.cyan.ndkfist.natives.UnistallLinstener;

import android.app.Activity;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/**
 * ����NDK�ķ�ʽ�����û�ж���Ժ����ҳ
 * @author wx
 *
 */
public class UninstallListenerActivity extends Activity {
	static{
		System.loadLibrary("com_cyan_ndkfist_natives_UnistallLinstener");
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_uninstall_listener);
		UnistallLinstener.listenUninstall(VERSION.SDK_INT,"com.cyan.ndkfirst");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.uninstall_listener, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
