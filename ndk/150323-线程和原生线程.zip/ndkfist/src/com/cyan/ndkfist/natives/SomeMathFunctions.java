package com.cyan.ndkfist.natives;

/**
 * �Ӽ��˳�
 * 
 * @author wangxu
 *
 */
public class SomeMathFunctions {
	/**
	 * ��
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static native int add(int a, int b);

	/**
	 * ��
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static native int subtract(int a, int b);

	/**
	 * ��
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static native int multiply(int a, int b);

	/**
	 * ��
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static native int divide(int a, int b);
}
