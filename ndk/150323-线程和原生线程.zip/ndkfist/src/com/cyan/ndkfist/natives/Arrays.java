package com.cyan.ndkfist.natives;

/**
 * �򵥵��������
 * 
 * @author
 *
 */
public class Arrays {
	/**
	 * ���
	 * 
	 * @param begin
	 * @param end
	 * @param ints
	 * @return
	 */
	public static native int sumFromIntArray(int begin, int end, int[] ints);

	/**
	 * ƴ�ӳ�һ���ַ���Ȼ�󷵻�
	 * 
	 * @param begin
	 * @param end
	 * @param ints
	 * @return
	 */
	public static native String appendString(int begin, int end, String[] ints);
}
