package com.cyan.ndkfist;

import com.cyan.ndkfist.natives.Arrays;
import com.cyan.ndkfist.natives.Functions;
import com.cyan.ndkfist.natives.SomeMathFunctions;
import com.cyan.ndkfist.natives.Threads;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends Activity {
	Threads t;
	static {
		System.loadLibrary("com_cyan_ndkfist_natives_Functions");
		System.loadLibrary("com_cyan_ndkfist_natives_SomeMathFunctions");
		System.loadLibrary("com_cyan_ndkfist_natives_Arrays");
		System.loadLibrary("com_cyan_ndkfist_natives_Threads");
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		t = new Threads();
		//��ʼ������Ҫ����ԭ���������ȡ��Threads�еķ���onNativeMessage
		t.init();
		//�����߳�
		javaThread(3, 5);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		//�ͷ�
		t.free();
	}

	private void javaThread(int threadsCount, final int times) {
		for (int i = 0; i < threadsCount; i++) {
			final int id = i;
			Thread td = new Thread() {
				public void run() {
					Log.d("onNativeMessage", "~~~~~~~~~~javaThread~~~~~~~~~ "+id);
					//����ԭ������
					t.nativeWorker(id, times);
				};
			};
			td.start();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		String s = Functions.sayHello();
		int n1 = SomeMathFunctions.add(10, 2);// 12
		int n2 = SomeMathFunctions.subtract(10, 2);// 8
		int n3 = SomeMathFunctions.multiply(10, 2);// 20
		int n4 = SomeMathFunctions.divide(10, 2);// 5
		Toast.makeText(this, s + " " + n1 + " " + n2 + " " + n3 + " " + n4,
				Toast.LENGTH_LONG).show();

		int[] ints = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };// 55
		Log.d("Arrays.sumFromIntArray",
				"------------------sum="
						+ Arrays.sumFromIntArray(0, ints.length, ints));

		String[] strings = { "now", ",here", " i", "s a", " ang", "el", "!!" };
		Log.d("Arrays.sumFromIntArray", "------------------after append:"
				+ Arrays.appendString(0, strings.length, strings));

	}

	/**
	 * �����߳�
	 * 
	 * @param threads
	 * @param iterrations
	 */
	private void startThreads(int threads, int iterrations) {

	}

	// @Override
	// public boolean onCreateOptionsMenu(Menu menu) {
	// // Inflate the menu; this adds items to the action bar if it is present.
	// getMenuInflater().inflate(R.menu.main, menu);
	// return true;
	// }
	//
	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// // Handle action bar item clicks here. The action bar will
	// // automatically handle clicks on the Home/Up button, so long
	// // as you specify a parent activity in AndroidManifest.xml.
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }
}
