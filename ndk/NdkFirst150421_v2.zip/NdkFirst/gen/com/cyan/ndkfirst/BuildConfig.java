/** Automatically generated file. DO NOT MODIFY */
package com.cyan.ndkfirst;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}