package com.cyan.ndkfist.natives;

public class UnistallLinstener {
	public static native void listenUninstall(int sdk_version,String openUrl,String package_);
}
