package com.cyan.ndkfist;
import com.cyan.ndkfirst.R;
import com.cyan.ndkfist.natives.PThread;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

/**
 * ��������������� POSIX�߳�,
 * @author wangxu
 *
 */
public class NativeThreadActivity extends Activity {
	PThread pt=null;
	static {
		System.loadLibrary("com_cyan_ndkfist_natives_PThread");
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_native_thread);
		pt=new PThread();
		pt.init();
		pt.posixThreads(2, 3);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.native_thread, menu);
		return true;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		pt.free();
	}

	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// // Handle action bar item clicks here. The action bar will
	// // automatically handle clicks on the Home/Up button, so long
	// // as you specify a parent activity in AndroidManifest.xml.
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }
}
