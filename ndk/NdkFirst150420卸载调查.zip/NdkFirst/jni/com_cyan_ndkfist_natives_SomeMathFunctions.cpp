#include "com_cyan_ndkfist_natives_SomeMathFunctions.h"
#include <jni.h>
#include <string.h>

JNIEXPORT jint JNICALL Java_com_cyan_ndkfist_natives_SomeMathFunctions_add(
		JNIEnv * env, jclass, jint a, jint b) {
	return a+b;
}

JNIEXPORT jint JNICALL Java_com_cyan_ndkfist_natives_SomeMathFunctions_subtract(
		JNIEnv * env, jclass, jint a, jint b) {
	return a-b;
}

JNIEXPORT jint JNICALL Java_com_cyan_ndkfist_natives_SomeMathFunctions_multiply(
		JNIEnv * env, jclass, jint a, jint b) {
	return a*b;
}

JNIEXPORT jint JNICALL Java_com_cyan_ndkfist_natives_SomeMathFunctions_divide(
		JNIEnv * env, jclass, jint a, jint b) {
	return a/b;
}
