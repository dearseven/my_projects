#include<iostream>
#include "stock10.h"
#include "mytime2.h"

#define PI 3.1418
double area_of_round(double);

int main(int arg,char*argv[]){
	{
    	double radius,area;
    	radius=-10;
    	do{
        	cout<<endl<<"radius= ";
        	if(radius<0.0){
             	radius++;
            	cout<<endl<<" error:radius can not be negative!";
            	continue;
        	}
        	area=area_of_round(radius);
        	cout<<endl<<" area="<<area<<" when radius="<<radius<<endl;
 			radius++;
    	}while(radius!=10);
    }
    //
    cout<<"##################################\n";
    {
		using std::cout;
		cout<<"Using constructors to create new object\n";
		//���Ǿ��ǲ�new���������ĵ��ù��� 
		Stock s1("NanoSmart",12,20.0);
		s1.show();
		cout<<"\n";
		Stock s2("BOFFO",2,100);
		s2.show();
		cout<<"\n";
		s1=Stock();
		s1.show();
		//new����ָ�룬��Ҫdelete 
		Stock *ss=new Stock("sss",205,2);
		ss->show();
		delete ss;
	
		//���ַ������ǵ�����ֻ��һ�������Ĺ��췽������������������Ĳ��� 
		Stock s3=5;
		s3.show();
	}
	 cout<<"##################################\n";
	{
		Time weeding(4,35);
		Time waxing(2,47);
		Time total;
		Time diff;
		Time adjusted;
		
		cout<<"weeding time =";
		weeding.show();
		cout<<endl;
		
		cout<<"waxing time =";
		waxing.show();
		cout<<endl;
		
		cout<<"total time =";
		total=weeding+waxing;
		total.show();
		cout<<endl;
		
		diff=weeding-waxing;
		cout<<"weeding - waxing =";
		diff.show();
		cout<<endl;
		
		adjusted=total*1.5;
		cout<<"adjusted =";
		adjusted.show();
		cout<<endl;
	}
    
    return 0;
}

double area_of_round(double r){
    return r*r*PI;
}
