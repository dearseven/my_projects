#include "tabtenn0.h"
#include <iostream>

TableTennisPlayer::TableTennisPlayer(const string &fn,const string & ln,bool ht):firstname(fn),lastname(ln),hasTable(ht){
} 

void TableTennisPlayer::Name()const{
	std::cout<< lastname <<" , "<<firstname<<endl;
}
TableTennisPlayer::~TableTennisPlayer(){
	std::cout<<"destory:"<< lastname <<" , "<<firstname<<endl;
}

void TableTennisPlayer::description()const{
	std::cout<<"description TableTennisPlayer"<<endl;
}
