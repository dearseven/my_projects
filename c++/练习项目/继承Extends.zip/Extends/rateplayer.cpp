#include "rateplayer.h"
#include <iostream>

//����Ĺ��췽����Ҫ���ø���Ĺ��췽�� 
RatePlayer::RatePlayer(unsigned int r,const string &fn,const string &ln ,bool ht):TableTennisPlayer(fn,ln,ht){
	rating=r;
}

RatePlayer::RatePlayer(const TableTennisPlayer &tp,unsigned int r):TableTennisPlayer(tp),rating(r){

}

void RatePlayer::description()const{
	std::cout<<"description RatePlayer"<<endl;
}
RatePlayer::~RatePlayer(){
std::cout<<"destory RatePlayer:"<< lastname <<" , "<<firstname<<endl;
}
