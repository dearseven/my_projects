#include<cstring>
#include<iostream>
#include"stringbad.h"

int  StringBad::num_strings=0;

StringBad::StringBad(const char *s){
	len=std::strlen(s);
	str=new char[len+1];
	std::strcpy(str,s);
	num_strings++;
	cout<<"constructor with char "<<endl;
}

StringBad::StringBad(){
	len=4;
	str=new char[len];
	std::strcpy(str,"c++");
	num_strings++;
	cout<<"constructor "<<endl;
}

StringBad::~StringBad(){
	cout<<"~StringBad()"<<endl;
	--num_strings;
	delete []str;
}

std::ostream & operator<<(std::ostream & os,const StringBad & sb){
	os<<sb.str;
	return os;
}

void StringBad:: showNum()const{
	cout<<str<<",num_strings= "<<num_strings<<endl;
}

void StringBad::setNewStr(const char * ns){
	str=NULL;
	delete []str;
	str=new char[len+1];
	std::strcpy(str,ns);
}

//���ƹ��캯��
StringBad::StringBad(const StringBad & sb){
	len=sb.len;
	str=new char[len+1];
	std::strcpy(str,sb.str);
	num_strings++;
	cout<<"Copy constructor "<<endl;
}

StringBad & StringBad::operator=(const StringBad & st){
	if(this==&st)
		return *this;
	delete []str;
	len=st.len;
	str=new char[len+1];
	std::strcpy(str,st.str);
	return *this;
}

void StringBad::showStr( StringBad &sb){
	cout<<"showStr:"<<sb.str<<",end \n";	
}
