#include <iostream>
#include <stdexcept>
#include "tvfm.h"
#include <stdio.h>
using namespace std;

//�������� 
bool exceptionTest(); 
bool exceptionTestWithTryCatch();

//����ǲ����࣬����include "tv.h"��"tvfm.h" ,tv.cpp������h�ļ���������������һ�� 
int main(int argc, char *argv[])
{
	cout<<"Hello C-Free!"<<endl;
	
	{
		Tv s42;
		cout<<"Initial setting for 42\' TV:\n";
		s42.settings();
		s42.onoff();
		s42.chanup();
		cout<<"adjusted settings for 42\' TV:\n";
		s42.settings();
		s42.chanup();
		cout<<"adjusted settings for 42\' TV:\n";
		s42.settings();
		
		Remote grey;
		grey.set_chan(s42,10);
		grey.volup(s42);
		grey.volup(s42);
		cout<<"\n42\' settings after using remote:\n";
		s42.settings();
		
		Tv s58(Tv::On);
		s58.set_mode();
		grey.set_chan(s58,28);
		cout<<"\n58\' settings:"<<endl;
		s58.settings();
	}
	//exception
	{	
		cout<<endl;
		bool ret=exceptionTest();
		cout<<"ִ�н��:"<<ret<<endl;
		
		try{
			exceptionTestWithTryCatch();
		}catch(const char * s){
			cout<<"!!!!!!!";
			cout<<s<<endl;
		}
		
		try{
			int a=1;
			int b=1;
			//int c=a/(a-b);
			
			double *bb=new double[1];
			bb[0]=222;
			cout<<bb[2]<<endl;
			delete []bb;
			
		 	char* p = NULL;  
       	 	strcpy(p, "test"); 
		}catch(exception & ex){
			cout<<"ex\n";
		}
	} 
	return 0;
};
	bool exceptionTest(){
		float a=2.0;
		int b=-2;
		float c=0.0;
		if(a==-b){
			cout<<"��������Ϊ��!\n";
			//��ʽ1 ����ֹ���� 
			//abort();
			
			//��ʽ2 ���ش�����Ϣ
			return false;
		}else{
		 	c=2*a*b/(a+b);
		 	cout<<"c="<<c<<endl;
		 	return true;
		}
	}
	
	bool exceptionTestWithTryCatch(){
		int a=2;
		int b=-2;
		if(a==-b)
			throw "a+b=0"; 
		int c=a/(a+b);
		return true;
	}
